from django.contrib import admin

from articles.models import article

admin.site.register(article)