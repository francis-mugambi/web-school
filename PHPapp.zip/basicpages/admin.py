from django.contrib import admin
from .models import contactFormModel

admin.site.register(contactFormModel)
