from django.apps import AppConfig


class JavaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Javaapp'
